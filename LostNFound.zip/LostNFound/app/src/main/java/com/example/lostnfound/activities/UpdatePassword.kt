package com.example.lostnfound.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.widget.Toast
import com.example.lostnfound.R
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_update_password.*

class UpdatePassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_password)
        val user = FirebaseAuth.getInstance().currentUser
        val txtNewPass: Editable? = new_pass.text
        button_update.setOnClickListener {
            if(new_pass.text==confirm_new_pass.text) {
                user!!.updatePassword(txtNewPass.toString()).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(
                            this,
                            "Your Password Has Been Updated Successfully",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    else {
                        Toast.makeText(this,
                            "Error Updating Your Password",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            else{
                Toast.makeText(this,
                    "New Password and Confirm New Password are not same",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}