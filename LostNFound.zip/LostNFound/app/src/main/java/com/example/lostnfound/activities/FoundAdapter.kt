package com.example.lostnfound.activities

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.lostnfound.R
import com.example.lostnfound.models.Lost
import com.example.lostnfound.models.Users
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.auth.User
import kotlinx.android.synthetic.main.activity_after_login_page.*
import kotlinx.android.synthetic.main.item.view.*
import java.io.IOException


class FoundAdapter(private val context: Context, courseModelArrayList: ArrayList<Lost>) :
    RecyclerView.Adapter<FoundAdapter.Viewholder>() {

    private val courseModelArrayList: ArrayList<Lost>
    private val userList: ArrayList<Users> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoundAdapter.Viewholder {
        // to inflate the layout for each item of recycler view.
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item, parent, false)
        return Viewholder(view).listen { pos, type ->
            val item = courseModelArrayList.get(pos)
            //TODO do other stuff here
//            Toast.makeText(context,item.name,Toast.LENGTH_SHORT).show()

            val useremail= item.user_email

        }


    }

    override fun onBindViewHolder(holder: FoundAdapter.Viewholder, position: Int) {
        // to set data to textview and imageview of each card layout
        val item: Lost = courseModelArrayList[position]

        holder.name_lost.text=item.name
        holder.phone_lost.text=item.phone
        holder.place_lost.text=item.place
        holder.desc_lost.text=item.description
        holder.found_it_button.text="Found it!"
        try {
            Glide     //using Glide to display image from url
                .with(context)
                .load(item.image)
                .centerCrop()
                .placeholder(R.drawable.ic_baseline_person_24)
                .into(holder.image_lost);
        }catch (e: IOException){
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        // this method is used for showing number of card items in recycler view.
        return courseModelArrayList.size
    }


    class Viewholder(view: View) : RecyclerView.ViewHolder(view) {
        var image_lost: ImageView = view.findViewById(R.id.imgae_lost_item)
        var name_lost: TextView = view.findViewById(R.id.mane_lost_item)
        var phone_lost: TextView = view.findViewById(R.id.phone_lost_item)
        var place_lost: TextView = view.findViewById(R.id.place_lost_item)
        var desc_lost: TextView = view.findViewById(R.id.desc_lost_item)
        var found_it_button: Button =view.findViewById(R.id.claim_button)
    }


    // Constructor
    init {
        this.courseModelArrayList = courseModelArrayList
    }

    fun <T : RecyclerView.ViewHolder> T.listen(event: (position: Int, type: Int) -> Unit): T {
        itemView.claim_button.setOnClickListener {
            event.invoke(getAdapterPosition(), itemViewType)
        }
        return this
    }
}
