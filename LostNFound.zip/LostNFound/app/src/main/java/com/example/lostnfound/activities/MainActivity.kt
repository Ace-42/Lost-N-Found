package com.example.lostnfound.activities

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.widget.Toast
import com.example.lostnfound.R
import com.example.lostnfound.firebase.firestoreclass
import com.example.lostnfound.models.Users
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : BaseActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        auth = FirebaseAuth.getInstance()
        println(Signup)
        Signup.setOnClickListener {
            val intentT = Intent(this,SignupPage::class.java)
            startActivity(intentT)
        }
        forgor_password.setOnClickListener {
            val email = Username.text.toString()
            if (email.isNotEmpty()) {
                auth.sendPasswordResetEmail(email).addOnCompleteListener {
                    if (it.isSuccessful) {
                        Toast.makeText(this,
                            "An email has been sent",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        Toast.makeText(this,
                            it.exception.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            } else {
                Toast.makeText(this,
                    "Please write your email in the space provided",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        Login_button.setOnClickListener{
            signInRegistered()
        }
}
    private fun signInRegistered()
    {
        val email=Username.text.toString().trim{it <=' '}
        val password=Login_password.text.toString().trim{it <=' '}

        if(validateForm(email, password))
        {
            showProgressDialog("Please Wait")
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    hideProgressDialog()
                    if (task.isSuccessful) {
                        if(auth.currentUser?.isEmailVerified==true){
                            firestoreclass().signInUser(this)
                        }
                        else{
                            Toast.makeText(this,
                                "Please Verify your email",
                                Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(baseContext, task.exception.toString(),
                            Toast.LENGTH_SHORT).show()
                    }
                }
        }


    }
    private fun validateForm(email:String,password:String):Boolean {
            if(TextUtils.isEmpty(password.trim { it <= ' ' })) {
                if (TextUtils.isEmpty(email.trim { it <= ' ' })) {
                    Toast.makeText(
                        this@MainActivity,
                        "Please Enter Your Email and Password",
                        Toast.LENGTH_SHORT
                    ).show()
                    return false
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "Please Enter Your Password",
                        Toast.LENGTH_SHORT
                    ).show()
                    return false
                }
            }

            else{
                if(TextUtils.isEmpty(email.trim { it <= ' ' })) {
                    Toast.makeText(
                        this@MainActivity,
                        "Please Enter Your Email",
                        Toast.LENGTH_SHORT
                    ).show()
                    return false
                }
                else {
                    return true
                }
            }
    }
        fun signInSuccess(user: Users){
            Toast.makeText(this,
                "Login successful :) ",
                Toast.LENGTH_LONG
            ).show()
            val goNext = Intent(this,AfterLoginPage::class.java)
            startActivity(goNext)
            finish()
        }
    }
