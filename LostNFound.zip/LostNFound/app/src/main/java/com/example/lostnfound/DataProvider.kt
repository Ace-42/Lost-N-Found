package com.example.lostnfound

object DataProvider {
    val lost_items= listOf<String>()
}