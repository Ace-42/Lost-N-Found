package com.example.lostnfound.utils

object Constants {
    const val USERS: String="users"
}